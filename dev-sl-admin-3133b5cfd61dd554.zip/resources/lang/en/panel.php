<?php

return [
    'site_title' => 'SL-ADMIN',
];
